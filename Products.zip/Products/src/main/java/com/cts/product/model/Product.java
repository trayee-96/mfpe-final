package com.cts.product.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Product {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	private String name;
	private float price;
	private String description;
	private String imageName;
	private float rating;
	private int count;
	
	public Product(int id, String name, float price, String description, String imageName) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		this.description = description;
		this.imageName = imageName;
		this.rating=0;
		this.count=0;
	}
	
}
