package com.cts.product.DAO;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.product.model.Product;

public interface ProductDAO extends JpaRepository<Product, Integer> {

	//Optional<Product> findByName(String name);

	List<Product> findByNameIgnoreCaseContaining(String name);

}
