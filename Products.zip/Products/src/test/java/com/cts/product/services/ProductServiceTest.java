package com.cts.product.services;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.cts.product.DAO.ProductDAO;
import com.cts.product.exception.AlreadyExistException;
import com.cts.product.exception.ProductNotFoundException;
import com.cts.product.model.Product;

@SpringBootTest
class ProductServiceTest {

	@Autowired
	ProductService productService;
	@MockBean
	ProductDAO dao;

	@Test
	void testGetProductId() {
		Product p = new Product(1, "Shoes", 2500, "Fully comfort shoe", "addidas");
		when(dao.findById(1)).thenReturn(Optional.of(p));
		assertEquals(productService.getProductId(1).get().getName(), p.getName());

	}

	@Test
	void testGetProductName() {
		List<Product> pr=new ArrayList<>();
		Product p = new Product(1, "Shoes", 2500, "Fully comfort shoe", "addidas");
		pr.add(p);
		when(dao.findByNameIgnoreCaseContaining("Shoes")).thenReturn(pr);
		assertEquals(productService.getProductName("Shoes").get(0).getName(), p.getName());
	}

	@Test
	void testAddRatings() throws ProductNotFoundException {
		Product p = new Product(1, "Shoes", 2500, "Fully comfort shoe", "addidas");
		when(dao.findById(1)).thenReturn(Optional.of(p));
		productService.addRatings(1,5);
		verify(dao).save(p);
	}
	@Test
	void testAddRatingsProductNotFoundException() {
		Product p = new Product(1, "Shoes", 2500, "Fully comfort shoe", "addidas");
		when(dao.findById(1)).thenReturn(Optional.empty());
		Exception exception = assertThrows(ProductNotFoundException.class, () ->productService.addRatings(1, 5));
		assertEquals("1not found", exception.getMessage());
	}
	@Test
	void testGetProducts() {
		List<Product> p = Stream.of(new Product(1, "Shoes", 2500, "Fully comfort shoe", "addidas"),
				new Product(1, "Shoes", 2500, "Fully comfort shoe", "addidas")).collect(Collectors.toList());
		when(dao.findAll()).thenReturn((List<Product>) p);
		assertEquals(productService.getProducts().get(0).getName(), ((List<Product>) p).get(0).getName());

		// fail("Not yet implemented");
	}

	@Test
	void testAddProduct() {
		Product p = new Product(1, "Shoes", 2500, "Fully comfort shoe", "addidas");
		when(dao.findById(1)).thenReturn(Optional.empty());
		// when(dao.save(p)).thenReturn(p);
		// assertEquals(service.addProduct(p),p);
		productService.addProduct(p);
		verify(dao).save(p);
	}

	@Test
	void testAddProductAlreadyExistException() {
		Product p = new Product(1, "Shoes", 2500, "Fully comfort shoe", "addidas");
		when(dao.findById(1)).thenReturn(Optional.of(p));
		// when(dao.save(p)).thenReturn(p);
		// assertEquals(service.addProduct(p),p);
		Exception exception = assertThrows(AlreadyExistException.class, () -> productService.addProduct(p));
		assertEquals("Product already exist!", exception.getMessage());
		// verify(dao).save(p);
	}

}
/*
 * 
 * @Test public void testaddItem() { Product d=new Product(1, "Shoes", 2500,
 * "Fully comfort shoe", "addidas"); Mockito.when(dao.save(d)).thenReturn(d);
 * assertEquals(service.addProduct(d),d); verify(dao).save(d);
 * 
 */