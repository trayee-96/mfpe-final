package com.cts.eCommercePortal.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestHeader;

import com.cts.eCommercePortal.exception.AccessUnauthorizedException;
import com.cts.eCommercePortal.exception.ProductNotFoundException;
import com.cts.eCommercePortal.model.CartRequest;
import com.cts.eCommercePortal.model.Product;

//@Headers("Content-Type: application/json")
@FeignClient(name = "prceedclient", url = "http://localhost:8082/api", fallback = ProceedClientFallback.class)
//@FeignClient(url="http://localhost:8081/api/")
public interface ProceedClient {
	@GetMapping("/getWishlist/{customerId}")
	public List<Product> getWishlist(@RequestHeader("Authorization") String token, @PathVariable int customerId);

	@GetMapping("/getCart/{customerId}")
	public List<CartRequest> getCart(@RequestHeader("Authorization") String token, @PathVariable int customerId);

	@DeleteMapping("/deleteProductFromCart/{customerId}/{productId}")
	public ResponseEntity<String> deleteProductFromCart(@RequestHeader("Authorization") String token,
			@PathVariable int customerId, @PathVariable int productId)
			throws ProductNotFoundException, AccessUnauthorizedException;

	@GetMapping("test")
	public String test();

	@PutMapping("/updateCart/{customerId}/{productId}/{qty}")
	public ResponseEntity<String> updateCart(@RequestHeader("Authorization") String token, @PathVariable int customerId,
			@PathVariable int productId, @PathVariable int qty);
	
	@PostMapping("/addProductToCart/{customerId}/{productId}/{zipCode}/{expectedDeliveryDate}")
	public ResponseEntity<String> addProductToCart(@RequestHeader("Authorization") String token,
			@PathVariable int customerId, @PathVariable int productId, @PathVariable int zipCode,
			@PathVariable String expectedDeliveryDate)
			throws  ProductNotFoundException, AccessUnauthorizedException ;
	@PutMapping("/updateVendor/{customerId}/{productId}/{qty}/{vendorId}")
	public ResponseEntity<String> updateVendor(@RequestHeader("Authorization")String token,@PathVariable int customerId,@PathVariable int productId,@PathVariable int qty,@PathVariable int vendorId);
	@PostMapping("/charge/{customerId}")
	public ResponseEntity<Double> getDeliveryCharge(@RequestHeader("Authorization") String token,@PathVariable int customerId);
	// calculate total cart amount except delivery charge
	@GetMapping("/total/{customerId}")
	public ResponseEntity<Float> calculateTotalForCart(@RequestHeader("Authorization") String token,@PathVariable int customerId)
			throws AccessUnauthorizedException;
}
