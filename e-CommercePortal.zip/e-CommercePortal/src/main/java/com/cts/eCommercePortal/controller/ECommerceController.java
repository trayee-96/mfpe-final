package com.cts.eCommercePortal.controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cts.eCommercePortal.client.AuthClient;
import com.cts.eCommercePortal.client.ProceedClient;
import com.cts.eCommercePortal.client.ProductClient;
import com.cts.eCommercePortal.client.VendorClient;
import com.cts.eCommercePortal.exception.AccessUnauthorizedException;
import com.cts.eCommercePortal.exception.ProductNotFoundException;
import com.cts.eCommercePortal.model.CartRequest;
import com.cts.eCommercePortal.model.UserAuth;
import com.cts.eCommercePortal.model.UserLoginCredential;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class ECommerceController {

	@Autowired
	AuthClient authClient;
	@Autowired
	ProductClient productClient;
	@Autowired
	ProceedClient proceedClient;
	@Autowired
	VendorClient vendorClient;
	@Autowired
	HttpSession httpSession;

	@GetMapping("/wishlist.html")
	public ModelAndView wishlist() {
		String token = (String) httpSession.getAttribute("token");
		// System.out.println("this is an index page");
		try {
			 proceedClient.getWishlist(token, authClient.getId(token));
		} catch (Exception e) {
			ModelAndView modelAndView = new ModelAndView("cartEmpty");
			return modelAndView;
		}
		ModelAndView modelAndView = new ModelAndView("wishlist");
		// modelAndView.addObject("list", eCommerceClient.getProducts());
		modelAndView.addObject("list", proceedClient.getWishlist(token, authClient.getId(token)));
		return modelAndView;
		// return "index";
	}

	@RequestMapping("/updateVendor/{vendorId}/{productId}/{qty}")
	public ModelAndView updateVendor(@PathVariable int vendorId, @PathVariable int productId, @PathVariable int qty)
			throws AccessUnauthorizedException {
		// System.out.println("this is a vendor page");
		String token = (String) httpSession.getAttribute("token");
		proceedClient.updateVendor(token, authClient.getId(token), productId, qty, vendorId);
		try {
			proceedClient.getCart(token, authClient.getId(token));
			}catch (Exception e) {
				ModelAndView modelAndView = new ModelAndView("cartEmpty");
				return modelAndView;
			}
		ModelAndView modelAndView = new ModelAndView("cart");
		// modelAndView.addObject("list", eCommerceClient.getProducts());

		modelAndView.addObject("list", proceedClient.getCart(token, authClient.getId(token)));
		float productTotal = proceedClient.calculateTotalForCart(token, authClient.getId(token)).getBody();
		modelAndView.addObject("productTotal", productTotal);
		double delivery = proceedClient.getDeliveryCharge(token, authClient.getId(token)).getBody();
		modelAndView.addObject("delivery", delivery);
		modelAndView.addObject("total", productTotal + delivery);
		// log.info(">>>>>>>>>>>>>>>>>>>>"+proceedClient.getCart(token,
		// authClient.getId(token)).);
		return modelAndView;
	}

	@RequestMapping("/vendors/{productId}/{qty}")
	public ModelAndView vendors(@PathVariable int productId, @PathVariable int qty) throws AccessUnauthorizedException {
		// System.out.println("this is a vendor page");
		String token = (String) httpSession.getAttribute("token");
		ModelAndView modelAndView = new ModelAndView("vendor");
		// modelAndView.addObject("list", eCommerceClient.getProducts());
		modelAndView.addObject("list", vendorClient.getVendors(token, productId, qty).getBody());
		modelAndView.addObject("productId", productId);
		modelAndView.addObject("qty", qty);
		// log.info(">>>>>>>>>>>>>>>>>>>>"+proceedClient.getCart(token,
		// authClient.getId(token)).);
		return modelAndView;
	}

	@GetMapping("/cart.html")
	public ModelAndView cart() throws AccessUnauthorizedException {
		/*
		 * System.out.println("this is a cart"); return "cart";
		 */
		String token = (String) httpSession.getAttribute("token");
		try {
			proceedClient.getCart(token, authClient.getId(token));
		} catch (Exception e) {
			ModelAndView modelAndView = new ModelAndView("cartEmpty");
			return modelAndView;
		}

		ModelAndView modelAndView = new ModelAndView("cart");
		// modelAndView.addObject("list", eCommerceClient.getProducts());
		modelAndView.addObject("list", proceedClient.getCart(token, authClient.getId(token)));
		float productTotal = proceedClient.calculateTotalForCart(token, authClient.getId(token)).getBody();
		modelAndView.addObject("productTotal", productTotal);
		double delivery = proceedClient.getDeliveryCharge(token, authClient.getId(token)).getBody();
		modelAndView.addObject("delivery", delivery);
		modelAndView.addObject("total", productTotal + delivery);

		// log.info(">>>>>>>>>>>>>>>>>>>>"+proceedClient.getCart(token,
		// authClient.getId(token)).);
		return modelAndView;
	}

	@GetMapping("/removeCart/{productId}")
	public ModelAndView removeCart(@PathVariable int productId)
			throws ProductNotFoundException, AccessUnauthorizedException {
		/*
		 * System.out.println("this is a cart"); return "cart";
		 */
		String token = (String) httpSession.getAttribute("token");
		try {
			proceedClient.getCart(token, authClient.getId(token));
		} catch (Exception e) {
			ModelAndView modelAndView = new ModelAndView("cartEmpty");
			return modelAndView;
		}
		proceedClient.deleteProductFromCart(token, authClient.getId(token), productId);
		ModelAndView modelAndView = new ModelAndView("cart");
		// modelAndView.addObject("list", eCommerceClient.getProducts());
		modelAndView.addObject("list", proceedClient.getCart(token, authClient.getId(token)));
		// log.info(">>>>>>>>>>>>>>>>>>>>"+proceedClient.getCart(token,
		// authClient.getId(token)).);
		float productTotal = proceedClient.calculateTotalForCart(token, authClient.getId(token)).getBody();
		modelAndView.addObject("productTotal", productTotal);
		double delivery = proceedClient.getDeliveryCharge(token, authClient.getId(token)).getBody();
		modelAndView.addObject("delivery", delivery);
		modelAndView.addObject("total", productTotal + delivery);
		return modelAndView;
	}

	@GetMapping("/updateCart/{productId}/{qty}")
	public ModelAndView updateCart(@PathVariable int productId, @PathVariable int qty)
			throws ProductNotFoundException, AccessUnauthorizedException {
		/*
		 * System.out.println("this is a cart"); return "cart";
		 */
		String token = (String) httpSession.getAttribute("token");
		try {
			proceedClient.getCart(token, authClient.getId(token));
		} catch (Exception e) {
			ModelAndView modelAndView = new ModelAndView("cartEmpty");
			return modelAndView;
		}
		proceedClient.updateCart(token, authClient.getId(token), productId, qty);
		ModelAndView modelAndView = new ModelAndView("cart");
		// modelAndView.addObject("list", eCommerceClient.getProducts());
		List<CartRequest> list = proceedClient.getCart(token, authClient.getId(token));
		log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + list.get(0).toString());
		modelAndView.addObject("list", list);
		// log.info(">>>>>>>>>>>>>>>>>>>>"+proceedClient.getCart(token,
		// authClient.getId(token)).);
		float productTotal = proceedClient.calculateTotalForCart(token, authClient.getId(token)).getBody();
		modelAndView.addObject("productTotal", productTotal);
		double delivery = proceedClient.getDeliveryCharge(token, authClient.getId(token)).getBody();
		modelAndView.addObject("delivery", delivery);
		modelAndView.addObject("total", productTotal + delivery);
		return modelAndView;
	}

	@RequestMapping("/index.html")
	public ModelAndView index() {
		String token = (String) httpSession.getAttribute("token");
		// System.out.println("this is an index page");
		ModelAndView modelAndView = new ModelAndView("index");
		// modelAndView.addObject("list", eCommerceClient.getProducts());
		modelAndView.addObject("list", productClient.getProduct(token));
		return modelAndView;
		// return "index";
	}

	@RequestMapping("/addProductRating/{productId}/{rating}")
	public ModelAndView addProductRating(@PathVariable int productId, @PathVariable int rating)
			throws ProductNotFoundException, AccessUnauthorizedException {
		String token = (String) httpSession.getAttribute("token");
		// System.out.println("this is an index page");
		productClient.addProductRating(token, productId, rating);
		ModelAndView modelAndView = new ModelAndView("index");
		// modelAndView.addObject("list", eCommerceClient.getProducts());
		modelAndView.addObject("list", productClient.getProduct(token));
		return modelAndView;
		// return "index";
	}

	@PostMapping("/addProductToCart/{productId}/{expectedDeliveryDate}")
	public ModelAndView addProductToCart(@PathVariable int productId, @PathVariable String expectedDeliveryDate)
			throws ProductNotFoundException, AccessUnauthorizedException {
		String preToken = (String) httpSession.getAttribute("token");
		/*
		 * log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>insideeeeeeeeeeeeeee"+
		 * preToken+"<<<<<"); log.info(credentials.toString()); String token ="Bearer "+
		 * authClient.login(credentials);
		 * log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + token);
		 * httpSession.setAttribute("token", token); //
		 * System.out.println("this is an index page");
		 */
		int custId = authClient.getId(preToken);
		int zip = authClient.getZip(preToken);
		log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>insideeeeeeeeeeeeeeeeeeee|||||||||||||||" + custId
				+ "||||||||||||" + zip);

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		expectedDeliveryDate = LocalDate.now().plusDays(7).format(formatter);
		proceedClient.addProductToCart(preToken, custId, productId, zip, expectedDeliveryDate);
		log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>insideeeeeeeeeeeeeeeeeeee|||||||||||||||" + custId
				+ "||||||||||||" + zip);

		ModelAndView modelAndView = new ModelAndView("index");
		// modelAndView.addObject("list", eCommerceClient.getProducts());
		// modelAndView.addObject("list", productClient.getProduct(token));
		return modelAndView;
		// return "index";
	}

	@GetMapping("/login.html")
	public String login(@ModelAttribute("credentials") UserLoginCredential credentials) {
		// System.out.println("this is a login page");
		httpSession.setAttribute("token", "");
		String preToken = (String) httpSession.getAttribute("token");
		log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>insideeeeeeeeeeeeeeeget" + preToken + "<<<<<");

		return "login";
	}

	@PostMapping("/login.html")
	public ModelAndView loginSubmit(@ModelAttribute("credentials") UserLoginCredential credentials) {
		String preToken = (String) httpSession.getAttribute("token");

		log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>insideeeeeeeeeeeeeee" + preToken + "<<<<<");
		log.info(credentials.toString());
		String token = "Bearer " + authClient.login(credentials);
		log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + token);
		httpSession.setAttribute("token", token);
		// System.out.println("this is an index page");
		ModelAndView modelAndView = new ModelAndView("index");
		// modelAndView.addObject("list", eCommerceClient.getProducts());
		modelAndView.addObject("list", productClient.getProduct(token));
		return modelAndView;
		// return "index";
	}

	@GetMapping("/signup.html")
	public String signup(@ModelAttribute("credentials") UserAuth credentials) {
		System.out.println("this is a signup page");
		return "signup";
	}

	@PostMapping("/signup.html")
	public ModelAndView signupSubmit(@ModelAttribute("credentials") UserAuth credentials) {
		String preToken = (String) httpSession.getAttribute("token");

		log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>insideeeeeeeeeeeeeee" + preToken + "<<<<<");
		log.info(credentials.toString());
		String token = "Bearer " + authClient.register(credentials);
		log.info(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + token);
		httpSession.setAttribute("token", token);
		// System.out.println("this is an index page");
		ModelAndView modelAndView = new ModelAndView("index");
		// modelAndView.addObject("list", eCommerceClient.getProducts());
		modelAndView.addObject("list", productClient.getProduct(token));
		return modelAndView;
		// return "index";
	}

	@RequestMapping("/searchByName/{q}")
	public ModelAndView index(@PathVariable String q) throws ProductNotFoundException, AccessUnauthorizedException {
		String token = (String) httpSession.getAttribute("token");
		// System.out.println("this is an index page");
		
		ModelAndView modelAndView = new ModelAndView("index");
		// modelAndView.addObject("list", eCommerceClient.getProducts());
		modelAndView.addObject("list", productClient.searchProductByName(token, q));
		return modelAndView;
		// return "index";
	}
}
