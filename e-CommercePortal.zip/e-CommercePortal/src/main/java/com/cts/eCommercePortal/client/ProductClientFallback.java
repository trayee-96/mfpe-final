package com.cts.eCommercePortal.client;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.cts.eCommercePortal.exception.AccessUnauthorizedException;
import com.cts.eCommercePortal.exception.ProductNotFoundException;
import com.cts.eCommercePortal.model.Product;

public class ProductClientFallback implements ProductClient {

	@Override
	public List<Product> getProduct(String token) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String test() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ResponseEntity<String> addProductRating(String token, int id, float rating)
			throws ProductNotFoundException, AccessUnauthorizedException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> searchProductByName(String token, String name)
			throws ProductNotFoundException, AccessUnauthorizedException {
		// TODO Auto-generated method stub
		return null;
	}

}
