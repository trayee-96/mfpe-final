package com.cts.eCommercePortal.client;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.cts.eCommercePortal.exception.AccessUnauthorizedException;
import com.cts.eCommercePortal.exception.ProductNotFoundException;
import com.cts.eCommercePortal.model.Product;
import com.cts.eCommercePortal.model.Vendor;

public class VendorClientFallback implements VendorClient {

	@Override
	public ResponseEntity<List<Vendor>> getVendors(String token, int productId, int quantity)
			throws AccessUnauthorizedException {
		// TODO Auto-generated method stub
		return null;
	}


}
