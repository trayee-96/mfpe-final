package com.cts.auth;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.cts.auth.service.CustomerDetailsService;
import com.cts.auth.util.JwtUtil;
@SpringBootTest
@AutoConfigureMockMvc
class AuthControllerTest {
	@Autowired
	private MockMvc mock;
	@MockBean
	CustomerDetailsService custdetailservice;
	@MockBean
	JwtUtil jwtutil;
	@Test
	void testTest() {
		//fail("Not yet implemented");
	}

//	@Test
//	void testRegister() throws UserAlreadyExistsException {
//		//UserLoginCredential ulc=new UserLoginCredential("ani","1245");
//		UserAuth auth=new UserAuth(1L,"Jimmi","Sahani","js","jioh","abc@fgmal.com","ednjfdf",747783);
//		assertEquals(testLogin(),custdetailservice.addUser(auth));
//	}

//	@Test
//	void testLogin() {
//		UserLoginCredential ulc=new UserLoginCredential("ani","1245");
//		when(custdetailservice.loadUserByUsername(ulc.getUname()))
//	}

	@Test
	void testGetValidity() throws Exception {
		
		when(jwtutil.validateToken("token")).thenReturn(true);
		mock.perform(get("/validate").header("Authorization", "token").accept("application/json")).andReturn();
			//.andExpect(status().isOk());
	}

	@Test
	void testGetId() throws Exception {
		when(jwtutil.validateToken("token")).thenReturn(true);
		mock.perform(get("/getId").header("Authorization", "token").accept("application/json")).andReturn();
	}

	@Test
	void testGetZip() throws Exception {
		when(jwtutil.validateToken("token")).thenReturn(true);
		mock.perform(get("/getZip").header("Authorization", "token").accept("application/json")).andReturn();
		//andExpect(status().isOk());
	}

}
