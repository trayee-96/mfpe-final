package com.cts.auth.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.cts.auth.exception.UserAlreadyExistsException;
import com.cts.auth.model.UserAuth;

public interface CustomerDetailsService extends UserDetailsService {

	boolean addUser(UserAuth userAuth) throws UserAlreadyExistsException;

	int getId(String extractUsername);

	UserAuth getUser(String extractUsername);
	
	

}
