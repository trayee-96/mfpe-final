package com.cts.auth.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity(name="user")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserAuth {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column
	private long userid;
	
	@Column
	private String firstName;
	
	@Column
	private String lastName;
	
	@Column(name="uname" ,length=20)
	private String uname;
	
	
	@Column(name="upassword",length=20)
	private String upassword;
	
	@Column(name="email")
	private String email;
	
	@Column(name="address")
	private String address;
	
	@Column(name="zipCode")
	private int zipCode;
	

	

	
}
