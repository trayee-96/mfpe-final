package com.cts.auth.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.auth.model.UserAuth;

@Repository
public interface UserDAO extends JpaRepository<UserAuth, String> {

	Optional<UserAuth> findByUname(String uname);
	
}
