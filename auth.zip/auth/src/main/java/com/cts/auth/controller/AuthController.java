package com.cts.auth.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.auth.exception.UserAlreadyExistsException;
import com.cts.auth.model.UserAuth;
import com.cts.auth.model.UserLoginCredential;
import com.cts.auth.service.CustomerDetailsService;
import com.cts.auth.util.JwtUtil;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/authapp")
@Slf4j
public class AuthController {

	@Autowired
	private JwtUtil jwtutil;

	@Autowired
	private CustomerDetailsService custdetailservice;

	@GetMapping(value = "/test")
	String test() {
		return "OK";
	}

	@PostMapping(value = "/register")
	public ResponseEntity<?> register(@RequestBody UserAuth userAuth) throws UserAlreadyExistsException {

		log.info("Inside class AuthController!!! RegisterMethod");
		log.info("Registering user");
		if(custdetailservice.addUser(userAuth))
		{
			return login(new UserLoginCredential(userAuth.getUname(), userAuth.getUpassword()));
		}
		else
		{
			return new ResponseEntity<>("SignUp Failed", HttpStatus.BAD_REQUEST);
			}
		

	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ResponseEntity<?> login(@RequestBody UserLoginCredential userlogincredentials) {
		log.info("Inside class AuthController!!! LoginMethod");
		log.info("Generating token");

		final UserDetails userdetails = custdetailservice.loadUserByUsername(userlogincredentials.getUname());

		String generateToken = jwtutil.generateToken(userdetails);
		log.info(generateToken);
		return new ResponseEntity<>(generateToken, HttpStatus.OK);

	}

	@RequestMapping(value = "/validate", method = RequestMethod.GET)
	public ResponseEntity<?> getValidity(@RequestHeader("Authorization") String bearerToken) {
		log.info("Inside class AuthContoller!!! getValidityMethod");
		log.info("Validating");
		String token = bearerToken.substring(7);
		boolean res = false;

		if (jwtutil.validateToken(token)) {
			log.info("Validation sucessful!!");
			res = true;

		} else {
			log.info("Validation unsucessful!!");
			res = false;
		}
		return new ResponseEntity<>(res, HttpStatus.OK);
	}

	@RequestMapping(value = "/getId", method = RequestMethod.GET)
	public ResponseEntity<?> getId(@RequestHeader("Authorization") String bearerToken) {
		log.info("Inside class AuthContoller!!! getId");
		log.info("Validating");
		String token = bearerToken.substring(7);
		int res;

		if (jwtutil.validateToken(token)) {
			log.info("Validation sucessful!!");
			res = custdetailservice.getId(jwtutil.extractUsername(token));

		} else {
			log.info("Validation unsucessful!!");
			res = 0;
		}
		return new ResponseEntity<>(res, HttpStatus.OK);
	}
	@RequestMapping(value = "/getZip", method = RequestMethod.GET)
	public ResponseEntity<?> getZip(@RequestHeader("Authorization") String bearerToken) {
		log.info("Inside class AuthContoller!!! getUser");
		log.info("Validating");
		String token = bearerToken.substring(7);
		UserAuth user = null;

		if (jwtutil.validateToken(token)) {
			log.info("Validation sucessful!!");
			user = custdetailservice.getUser(jwtutil.extractUsername(token));

		} 
		return new ResponseEntity<>(user.getZipCode(), HttpStatus.OK);
	}

}
