INSERT INTO "PUBLIC"."USER" 
values (1, 'a','a','a','a','a','a',12548),
(2, 'a','a','a','a','prithwijit','a',12548),
(3, 'a','a','a','a','anindita','a',61210321),
(4, 'a','a','a','a','porush','a',12548847)
;